#ifndef FUNKCJA_H   // zapewnia najwyzej jednokrotne wlaczenie tego pliku
#define FUNKCJA_H 

// funkcja wypisująca identyfikatory procesu
void wypiszIDProcesu();

#endif