/* 
 Program wczytuje dane z pliku podanego przez argument wywołania programu
 porcjami po DATA_RATE bajtów i zapisuje je do potoku.
 Następnie tworzy proces potomny, uruchamia w nim program i przekazuje mu
 deskryptor potoku i ilość zapisanych w nim bajtów
 ----------------------------------------------------------------------
 Autor: Jan Krzemień,                               Krakow, 14.04.2023
 ----------------------------------------------------------------------
*/ 

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/param.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#define _GNU_SOURCE
#define PATH "./"
#define N 100

#define DATA_RATE 32
#define BUFFER_SIZE 200

int main(int argc, char *argv[])
{
    // oczekiwane są 3 argumenty: nazwa programu do uruchomienia w procesie potomnym
    // nazwa pliku do pobrania danych i nazwa pliku do zapisania danych
    if(argc != 4)
    {
        perror("niewłaściwa ilość argumentów wywołania programu\n");
	exit(1);
    }

    // łączenie nazw plików ze ścieżkami w pętli, dla każdego z 3 plików
    // przekazanych przez argumenty wywołania programu
    char pathName[3][N];
    int i;
    for(i = 0; i < 3; i++)
    {
    	if( snprintf(pathName[i], N, "%s%s", PATH, argv[1 + i]) < 0 )
	{
	    perror("nie udało się zapisać ciągów znaków do jednej tablicy za pomocą funkcji snprintf\n");
	    exit(2);
	}
    }


    // otworzenie pliku i przypisanie jego deskryptora do zmiennej
    printf("Otwieranie pliku %s ...\n", pathName[1]);
    int deskryptor = open(pathName[1], O_RDONLY, "rw-r--r--");
    if( deskryptor == -1 )
    {
	perror("nie udało się otworzyć pliku, porażka funkcji open\n");
        exit(3);
    }
    printf("Plik otworzony\n\n");

    printf("Tworzenie potoku...\n");
    // utworzenie potoku, jego deskryptory są zapisane w tablicy potok
    int potok[2];
    if(pipe(potok) == -1)
    {
        perror("błąd nie udało się otworzyć potoku funkcją pipe\n");
	exit(4);
    }
    printf("Potok utworzony\n\n");

    // odczyt z pliku i wysłanie do potoku
    int odczytanoBajtow, zapisanoBajtow;
    int bajtowLacznie = 0;
    char buffer[BUFFER_SIZE];
    printf("Rozpoczynam przesyłanie danych do potoku...\n\n");
    // funkcja read odczytuje z pliku dane w porcjach określonych przez DATA_RATE
    // jeśli zostaną odczytane wszystkie dane odczytanoBajto będzie równe 0,
    // w przypadku błędu odczytanoBajtow będzie równe -1 i po zakończeniu pętli błąd zostanie obsłużony
    while( ( odczytanoBajtow = read(deskryptor, (void*)buffer, DATA_RATE) ) && odczytanoBajtow > 0)
    {
        printf("odczytano %d bajtów z pliku...\n", odczytanoBajtow);
        // zapisanie do potoku, połączone z obsługą błędów funkcji write
        if( ( zapisanoBajtow = write(potok[1], (void*)buffer, odczytanoBajtow) ) && zapisanoBajtow == -1)
        {
            perror("zapisanie danych do potoku nie powiodło się, funkcja write zwróciła -1\n");
            exit(5);
        }

        printf("zapisano %d bajtów w potoku...\n", zapisanoBajtow);
        printf("zapisane dane: ");
        // wypisanie danych na ekranie za pomocą funkcji write
        if( write(1, (void*)buffer, zapisanoBajtow) == -1 )
        {
            perror("wypisanie danych standardowym wyjściem nie powiodło się, funkcja write zwróciła -1\n");
            exit(13);
        }
        printf("\n");

        // zliczanie zapisanych w potoku bajtów by przekazać to do procesu potomnego
        bajtowLacznie += zapisanoBajtow;

        printf("łącznie w potoku zapisano %d\n\n", bajtowLacznie);
    }
    if(odczytanoBajtow == -1) // obsługa błędów funkcji read
    {
        perror("odczytanie danych z pliku nie powiodło się, funkcja read zwróciła -1\n");
	    exit(6);
    }
    printf("przesyłanie danych do potoku zakończone\n\n");

    // zamiana int na char[]
    char deskrOdczytuPotoku[5];
    char bajtowWPotoku[20];
    if( snprintf(deskrOdczytuPotoku, 5, "%d", potok[0]) < 0 || snprintf(bajtowWPotoku, 20, "%d", bajtowLacznie) < 0 )
    {
        perror("snprintf error, nie udało się zamienić int na ciąg znaków");
        exit(7);
    }

    // stworzenie procesu potomnego i wywołanie w nim programu
    switch(fork())
    {
        case -1:
	    perror("fork error");
	    exit(8);
	case 0:
	    execlp(pathName[0], argv[1], pathName[2], deskrOdczytuPotoku, bajtowWPotoku, (char*) NULL);
	    perror("execlp error");
	    _exit(9);
	default:
	    if(wait(NULL) == -1)
	    {
            perror("wait error\n");
		    exit(10);
	    }
    }

    // zamknięcie potoku
    if(close(potok[1]) == -1)
    {
        perror("błąd podczas zamknięcia potoku\n");
        exit(11);
    }

    // zamknięcie pliku do odczytu danych
    if(close(deskryptor) == -1)
    {
        perror("błąd podczas zamknięcia pliku funkcją close\n");
	    exit(12);
    }

    return 0;
}
