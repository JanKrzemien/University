/* 
 Program wczytuje dane z potoku za pomocą deskryptora
 przekazanego przez argument wywołania programu
 porcjami po DATA_RATE bajtów i zapisuje je do pliku.
 ----------------------------------------------------------------------
 Autor: Jan Krzemień,                               Krakow, 14.04.2023
 ----------------------------------------------------------------------
*/ 

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define DATA_RATE 20
#define BUFFER_SIZE 200

int main(int argc, char *argv[])
{
    // oczekiwane są 4 argumenty: nazwa aktualnie uruchomionego programu
    // nazwa pliku do zapisania danych, deskryptor odczytu z potoku, ilość bajtów do odczytu
    if(argc != 4)
    {
        perror("niewłaściwa liczba argumentów w procesie potomnym\n");
	    exit(1);
    }


    // zamiana ciągu znaków na int żeby mieć dostęp do deskryptora potoku i ilości bajtów zapisanych w nim
    int potokOdczyt = atoi( argv[2] );
    int iloscBajtow = atoi( argv[3] );
    if( potokOdczyt == 0 || iloscBajtow == 0 )
    {
        perror("zamiana string na char za pomocą funkcji atoi nie powiodła się\n");
	    exit(2);
    }

    // otworzenie pliku i przypisanie jego deskryptora do zmiennej
    printf("otwieram plik %s w trybie do zapisu...\n", argv[1]);
    int deskryptor = open(argv[1], O_WRONLY, "rw-rw-rw-");
    if( deskryptor == -1 )
    {
        perror("otworzenie pliku w trybie zapisu za pomocą funkcji open nie powiodło się\n");
	    exit(3);
    }
    printf("plik otworzony\n\n");

	
    // ustawienie seed'a dla funkcji rand,
    // time(0) jako argument zagwarantuje że liczby wylosowane będą
    // się różniły pomiędzy wywołaniami programu
    srand( time(0) );

    // odczyt danych z potoku i zapis do pliku
    unsigned int losoweOpoznienie;
    int odczytanoBajtow, zapisanoBajtow;
    char buffer[BUFFER_SIZE];
    printf("rozpoczynam odczyt z potoku...\n");
    // odczyt danych z potoku tak długo jak z potoku można odczytać porcje DATA_RATE danych
    // lub aż do napotkania błędu lub końca pliku
    while( iloscBajtow >= DATA_RATE && ( odczytanoBajtow = read(potokOdczyt, (void*)buffer, DATA_RATE) ) && odczytanoBajtow > 0 )
    {
        printf("odczytano %d bajtów z potoku...\n", odczytanoBajtow);
        // usleep usypia program na ilość mikrosekund
        // 1 sekunda = 1 000 000 mikrosekund
        losoweOpoznienie = rand()%1000000;
	    printf("usypiam program na %d mikrosekund\n", losoweOpoznienie);
	    usleep(losoweOpoznienie);

        // zapis danych do pliku połączony z obsługą błędów funkcji write
        if( ( zapisanoBajtow = write(deskryptor, (void*)buffer, odczytanoBajtow) ) && zapisanoBajtow == -1 )
        {
            perror("błąd podczas zapisywania danych w pliku za pomocą funkcji write\n");
            exit(4);
        }
        printf("zapisano %d bajtów w pliku...\n", zapisanoBajtow);
        printf("zapisane dane: ");
        // wypisanie danych na ekranie za pomocą funkcji write
        if( write(1, (void*)buffer, zapisanoBajtow) == -1 )
        {
            perror("wypisanie danych standardowym wyjściem nie powiodło się, funkcja write zwróciła -1\n");
            exit(8);
        }
        printf("\n");

        // zmiana informacji o ilości bajtów które pozostały w potoku
	    iloscBajtow -= zapisanoBajtow;

	    printf("w potoku pozostało %d bajtów...\n\n", iloscBajtow);
    }
    if( odczytanoBajtow == -1 ) // obsługa błędów dla funkcji read znajdującej się w warunku pętli while
    {
        perror("błąd podczas odczytu danych z potoku za pomocą funkcji read");
	    exit(5);
    }

    // odczytanie danych pozostałych w potoku gdy ilość bajtów która w nim została jest mniejsza od DATA_RATE
    if( iloscBajtow > 0 && ( odczytanoBajtow = read(potokOdczyt, (void*)buffer, iloscBajtow) ) && odczytanoBajtow > 0)
    {
        printf("odczytano %d bajtów z potoku...\n", odczytanoBajtow);

        // usleep usypia program na losową ilość mikrosekund
        // 1 sekunda = 1 000 000 mikrosekund
        losoweOpoznienie = rand()%1000000;
        printf("usypiam program na %d mikrosekund\n", losoweOpoznienie);
        usleep(losoweOpoznienie);

        // zapis danych do pliku połączony z obsługą błędów funkcji write
        if( ( zapisanoBajtow = write(deskryptor, (void*)buffer, odczytanoBajtow) ) && zapisanoBajtow == -1 )
        {
            perror("błąd podczas zapisywania danych w pliku za pomocą funkcji write\n");
            exit(4);
        }
        printf("zapisano %d bajtów w pliku...\n", zapisanoBajtow);
        printf("zapisane dane: ");
        // wypisanie danych na ekranie za pomocą funkcji write
        if( write(1, (void*)buffer, zapisanoBajtow) == -1 )
        {
            perror("wypisanie danych standardowym wyjściem nie powiodło się, funkcja write zwróciła -1\n");
            exit(9);
        }
        printf("\n");

        // zmiana informacji o ilości bajtów które pozostały w potoku
        iloscBajtow -= zapisanoBajtow;

        printf("w potoku pozostało %d bajtów...\n\n", iloscBajtow);

        }
    if( odczytanoBajtow == -1 ) // obsługa błędów dla funkcji read znajdującej się w warunki instrukcji if
    {
        perror("błąd podczas odczytu danych z potoku za pomocą funkcji read");
	    exit(5);
    }

    printf("zakończono przesyłanie danych z potoku do pliku %s\n\n", argv[1]);

    // zamknięcie potoku
    if( close(potokOdczyt) == -1 )
    {
        perror("nie udało się zamknąć pliku za pomocą funkcji close\n");
	    exit(6);
    }

    // zamknięcie pliku do zapisywania danych
    if( close(deskryptor) == -1 )
    {
        perror("nie udało się zamknąć pliku za pomocą funkcji close\n");
	    exit(7);
    }

    return 0;
}
